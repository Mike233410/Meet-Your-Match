# Dating CPA Landing Page

A single-file dynamic dating offer landing page (`index.html`).

## How to Run
```
python3 -m http.server 5000
```
The workflow "Start application" is already configured for this.

## How to Plug In Your CPA Link
Open `index.html` and find this line near the bottom of the `<script>` block:
```js
const CPA_URL = '#your-cpa-offer-link';
```
Replace `#your-cpa-offer-link` with your actual CPA offer URL.

## Features
- **Auto-rotating hero slideshow** — 5 romantic couple photos cycling every 4.5 s
- **Floating hearts animation** — hearts/emojis rise continuously in the background
- **Live activity ticker** — scrolling strip of fake real-time match notifications
- **Places grid** — 6 location cards (beach, restaurant, mountain, city, park, travel)
- **Animated stat counters** — trigger on scroll (members, matches, couples, countries)
- **Success stories** — 3 testimonial cards with avatars, stars, and quotes
- **How It Works** — 4-step explainer section
- **Final CTA section** — second conversion button

## User Preferences
- Keep everything in a single `index.html` file (no build step needed)
